/**
 * The classes in this package are used for post-processing Books.
 * Things like cleaning up the html, adding a cover page, etc.
 */
package nl.siegmann.epublib.bookprocessor;