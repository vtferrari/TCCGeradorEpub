package nl.siegmann.epublib.domain;

public interface ManifestProperties {

	public String getName();
}
